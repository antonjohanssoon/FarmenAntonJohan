﻿namespace Farm.anton.johan
{
    public class Program
    {
        static void Main(string[] args)
        {
            Farm farm = new Farm();
            farm.MainMenu();
        }
    }
}